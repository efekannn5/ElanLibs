from main import *

__all__ = ["main"]


__version__ = "0.1.0"
__author__ = "Efekan Nefesoğlu"
__license__ = "MIT"