from math_utils import math_utils
from string_utils import string_utils
from image_utils import image_utils
from list_utils import list_utils


class main:
    # math
    math = math_utils()
    # string
    string = string_utils()
    # list
    list = list_utils()
    # image
    image = image_utils()


if __name__ == "__main__":
    main()

