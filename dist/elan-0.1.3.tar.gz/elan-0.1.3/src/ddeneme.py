from main import main

sayi = main()

print(sayi.math.cube(15))

print(sayi.string.reverse("Hello"))
