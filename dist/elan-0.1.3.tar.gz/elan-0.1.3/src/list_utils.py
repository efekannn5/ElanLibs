class list_utils:
    def __init__(self):
        pass

    def reverse(self, list):
        return list[::-1]   
    
    def sort(self, list):
        return sorted(list)
    
    def reverse(self, list):
        return list[::-1]   
   
    def unique(self, list):
        return list(set(list))
    
    
    
if __name__ == "__main__":
    list_utils()
    

